#!/bin/bash

#Длина удава N метров, высота попугая - M сантиметров. Какова длина удава в попугаях ?

length()
{
    local N=$1
    local M=$2
    length_Boa=$(( $N * 100 ))

    length=$(bc<<<"scale=3;$length_Boa/$M")
    echo "$length"
}
