#!/bin/bash

echo "**************** Задание 1 ****************"

#переменные в которых находятся цвета
#цвет текста
RED_TEXT='\033[1;31m' 

IFS=$':'

for folder in $PATH
do

        for file in $folder/*git* "$folder/"*Git* #файлы, имя которых содержит "git" 
        do
            if [ -x "$file" ] && [ -f "$file"  ] # Проверяем, что это файл и он исполняемый
            then
                echo -e "$RED_TEXT $file $NC"
            else
                continue
            fi
        done

done


