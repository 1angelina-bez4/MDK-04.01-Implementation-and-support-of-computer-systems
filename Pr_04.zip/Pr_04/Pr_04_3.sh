#!/bin/bash

echo "**************** Задание 3 ****************"

symbols=(0 1 2 3 4 5 6 7 8 9 a b c d e f g h i j k l m n o p q r s t u v w x y z)



while true; 
do
    password=""
    for i in {1..64}; #Генерируем пароль из 64 символов
    do
        index=$(( $RANDOM % ${#symbols[@]} ))
        password+="${symbols[$index]}"
    done
    # Выводим пароль синим цветом (ANSI-код 34)
    echo -e "\033[34m$password\033[0m"
    # Выход из бесконечного цикла (можно убрать, если нужен постоянный вывод)
    break
done