#!/bin/bash

echo "**************** Задание 2 ****************"

file_csv="supplier_k_import.csv"

# Проверяем существование файла
if [ ! -f "$file_csv" ]; then
    echo "Ошибка: файл '$file_csv' не найден!"
    exit 1
fi

while IFS=';' read -ra fields; do
    # Пропускаем заголовок
    [[ "${fields[0]}" == *"Наименование поставщика"* ]] && continue

    # Получаем поля по индексам
    name="${fields[0]}"
    type="${fields[1]}"
    inn="${fields[2]}"
    city="${fields[3]}"
    rating="${fields[4]}"
    email="${fields[5]}"
    date="${fields[6]}"

    # Очищаем значения: убираем пробелы, заменяем запятую на точку
    type=$(echo "$type")
    rating=$(echo "$rating")

    # Проверяем, что rating — корректное число (целое или дробное)
    if ! [[ "$rating" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
        continue  # пропускаем строку с некорректным рейтингом
    fi

    # Проверяем: "ООО" в типе и рейтинг > 70
    if [[ "$type" == *"ООО"* ]] && (( $(echo "$rating" > 70 | bc -l) )); then
        # Выводим строку в исходном формате (через ;)
        printf "%s\n! "$(IFS=';'; echo "${fields[*]}")
    fi
done < "$file_csv"
