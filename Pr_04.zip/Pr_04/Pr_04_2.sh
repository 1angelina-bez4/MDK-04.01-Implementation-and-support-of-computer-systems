#!/bin/bash

echo "**************** Задание 2 ****************"

file_csv="supplier_k_import.csv"
IFS=';'

while read -r name type inn rating date; do

  [[ "$name" == *"Наименование поставщика"* ]] && continue
  
  #создаем переменные для поиска 
  type=$(echo "$type")
  rating=$(echo "$rating")

  # Проверяем: "ООО" в названии и рейтинг > 70
  if [[ "$type" == *"ООО"* ]] && (( $(echo "$rating > 70" | bc -l) )); then
    echo "$name;$type;$inn;$city;$rating;$email;$date"
  fi
done < "$file_csv"