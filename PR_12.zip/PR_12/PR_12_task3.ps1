﻿# Выполнение запроса к корневому API
$response = Invoke-WebRequest -Uri "https://swapi.online/" -UseBasicParsing

# Преобразование JSON-ответа в объект PowerShell
$data = $response.Content | ConvertFrom-Json

# Вывод каждой категории в виде ссылки
foreach ($property in $data.PSObject.Properties) {
    $categoryName = $property.Name
    $categoryUrl = $property.Value
    
    Write-Host "Категория: $categoryName" 
    Write-Host "  URL: $categoryUrl" 
    Write-Host ""
}

$categories = $data.PSObject.Properties.Name

foreach ($category in $categories) {
        $categoryUrl = $data.$category
        $categoryResponse = Invoke-WebRequest -Uri $categoryUrl -UseBasicParsing -ErrorAction Stop
        $categoryData = $categoryResponse.Content | ConvertFrom-Json
        
        $itemCount = $categoryData.count
        Write-Host "$category : $itemCount элементов"  
}

$peopleResponse = Invoke-WebRequest -Uri "https://swapi.online/" -UseBasicParsing
    $peopleData = $peopleResponse.Content | ConvertFrom-Json
    
    for ($i = 0; $i -lt [Math]::Min(5, $peopleData.results.Count); $i++) {
        $person = $peopleData.results[$i]
        Write-Host "Персонаж $($i+1): $($person.name)" 
        Write-Host "  Рост: $($person.height) см"
        Write-Host "  Вес: $($person.mass) кг" 
        Write-Host "  Цвет волос: $($person.hair_color)" 
        Write-Host "  Цвет кожи: $($person.skin_color)" 
        Write-Host "  Цвет глаз: $($person.eye_color)"
        Write-Host "  Год рождения: $($person.birth_year)" 
        Write-Host "  Пол: $($person.gender)" 
    }