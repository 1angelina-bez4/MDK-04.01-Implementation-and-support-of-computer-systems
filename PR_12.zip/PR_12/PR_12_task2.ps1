﻿#Название и расположение  csv файла
$csvPath = ".\active_hosts.csv"

#Загружение данные из CSV
$hosts = Import-Csv -Path $csvPath

# Массив для результатов
$results = @()

foreach ($hostEntry in $hosts) {

    $hostname = $hostEntry.Host
    $ip = $hostEntry.IP

    # Пропускаем записи без DNS‑имени
    if ($hostname -eq "Неизвестно") {
        continue
    }

    Write-Host "Опрашиваем хост: $hostname ($ip)" -ForegroundColor Cyan

    # Проверяем доступность по DNS‑имени
    $isOnlineByDNS = Test-Connection -ComputerName $hostname -Count 1 -Quiet

    # Создаем пустой объект и добавляем свойства через Select
    $obj = "" | Select-Object Host, IP, Status
    $obj.Host = $hostname
    $obj.IP = $ip
    $obj.Status = if ($isOnlineByDNS) { "Online" } else { "Offline" }

    $results += $obj
}

# Сохраняем результаты инвентаризации
$inventoryPath = ".\inventory_results.csv"
 #Создание переменой в которой будет выборка конкретных свойств IP, DNS и Status И  экспортирует полученные объекты в CSV‑файл
$results | Export-Csv -Path $inventoryPath -NoTypeInformation -Encoding UTF8

Write-Host "Обработано хостов: $($results.Count)" 
Write-Host "Результаты инвентаризации сохранены в: $inventoryPath"
