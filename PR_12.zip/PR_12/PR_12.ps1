﻿#Создание переменной в которой будет содержаться информация об Ip адресе и маске
#для получения информации об IP‑адресах, настроенных на сетевых адаптерах на лок. комп
$info = Get-NetIPAddress -AddressFamily IPv4 |  Select-Object -First 1

#Where-Object {$_.InterfaceAlias -notlike "*Loopback*" -исключает 127.0.0.1 -and $_.PrefixOrigin -ne "WellKnown" - убирает служебные адреса} 

# заносим в переменые IP-адрес и маску подсети
$ip = $info.IPAddress
$pref = $info.PrefixLength

#выводим информацию об ip-адресе и маске
Write-Host "IP‑адрес: $ipAddress, маска: /$prefixLength"

#Разбиение IP‑адреса (на октеты)

$ipParts = $ip.Split('.')
$first = [int]$ipParts[0]
$second = [int]$ipParts[1]
$third = [int]$ipParts[2]
$fourth = [int]$ipParts[3]

#Вычисление количества хостов в подсети
$start = 1
$endOctet = 254

# Массив для результатов
$results = @()

#перебирание  IP‑адреса в диапазоне с первого октета  до последнего

foreach ($i in $start..$end)
{
    #Заносим в переменую ip с текущим номером хоста в диапазоне
     $beginning_enumerationIP = "$first.$second.$third.$i"
      # Пропускаем свой IP
    if ($beginning_enumerationIP -eq $ip) {
        continue
    }


     #производение опроса всех возможных IP-адреса в данной подсети с помощью командлета Test-Connection
     $host_availability = Test-Connection -ComputerName $beginning_enumerationIP -Count 1 -Quiet

     #если хост активный то получаем DNS-имя и заносим в массив
     if ($host_availability) {
        Write-Host "Хост $beginning_enumerationIP  активен"

        # Пытаемся получить DNS‑имя
        $dnsResult = Resolve-DnsName -Name $beginning_enumerationIP -Type PTR -ErrorAction SilentlyContinue
        if ($dnsResult) {
            $hostname = $dnsResult.NameHost
        } else {
                $hostname = "Неизвестно"
        }
        # Создаем пустой объект и добавляем свойства через Select
        $obj = "" | Select-Object Host, IP, Status
        $obj.Host = $hostname
        $obj.IP = $beginning_enumerationIP
        $obj.Status = if ($host_availability) { "Online" } else { "Offline" }

        $results += $obj

        #название и расположение  csv файла
        $csvPath = ".\active_hosts.csv"
        #Создание переменой в которой будет выборка конкретных свойств IP, DNS и Status И  экспортирует полученные объекты в CSV‑файл
       $results | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8 -Delimiter ','

    } else {
        #Вывод недоступных хостов
        Write-Host "Хост $beginning_enumerationIP  недоступен" 
    }
}

Write-Host "Результаты сохранены в файл: $csvPath" 

