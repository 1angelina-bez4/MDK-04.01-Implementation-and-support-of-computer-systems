﻿
Import-Csv -Path ".\active_hosts.csv" |
    Where-Object { $_.Host -ne "Неизвестно" } |
    ForEach-Object {
        $isOnline = Test-Connection -ComputerName $_.Host -Count 1 -Quiet
        [PSCustomObject]@{
            Host = $_.Host
            IP = $_.IP
            Status = if ($isOnline) { "Online" } else { "Offline" }
        }
    } |
    Export-Csv -Path ".\inventory_quick.csv" -NoTypeInformation -Encoding UTF8

Write-Host "Быстрая инвентаризация завершена. Результаты в inventory_quick.csv"